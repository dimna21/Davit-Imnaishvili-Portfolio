#include <iostream>
#include <fstream>
#include <string>
#include <cctype>
#include <vector>
#include <unordered_map>
#include <set>
#include <stack>
using namespace std;

const int RAM_SIZE = 100000000; //starting simulated RAM in BYTES.(100 MB when initialized, can be modified)
char m[RAM_SIZE];// Simulates heap and stack of our emulator with RAM_SIZE bytes
int x[100]; // Simulates the memory for 100 registers
set<string> validCommands;
int sp = RAM_SIZE;
int ra = 1;
bool checkedRA = false;
int lastAllocationIdx = 0;
stack<int> allocIndexes;

/* Converts a string to lowercase */
string lowercase(const string& s) {
    string result;
    for (char c: s) {
        result += tolower(static_cast<unsigned char>(c));
    }
    return result;
}
/*********************** This section contains implementation of all the assembly methods **************************/

/* Assumes that the line has a form of: (li x11, 9) without trailing spaces */
void li(const string& reg, const string& value){
    int regIdx = stoi(reg.substr(1, reg.length() - 1));
    int val = stoi(value);
    x[regIdx] = val;
}

/* Assumes that the line has a form of: (lw x11, 3(sp)) or (lw x11, 4(x12)) without trailing spaces */
void lw(const string& reg, const string& from){
    if(reg == "ra"){ //handle (lw ra, 4(sp))
        int leftBracketIdx = from.find('(');
        int rightBracketIdx = from.find(')');
        int offset = stoi(from.substr(0, from.length() - (rightBracketIdx - leftBracketIdx + 1)));
        memcpy(&ra, &m[sp + offset], sizeof(int));
        return;
    }
    int regIdx = stoi(reg.substr(1, reg.length() - 1));
    int leftBracketIdx = from.find('(');
    int rightBracketIdx = from.find(')');
    string s = from.substr(leftBracketIdx+1); // x12) or sp)
    if(s[0] == 'x'){ // from of: lw x11, 4(x12) - Meaning that we want to load whatever is on (x12+4) address in memory.
        s = s.substr(1, s.length()-2); //12
        int reg1Val = x[stoi(s)]; // value of address stored in x12
        int offset =  stoi(from.substr(0, from.length() - (rightBracketIdx - leftBracketIdx + 1)));
        memcpy(&x[regIdx], &m[reg1Val + offset], sizeof(int));
    }else{ // from of: lw x11, 4(sp)
        int offset = stoi(from.substr(0, from.length() - (rightBracketIdx - leftBracketIdx + 1)));
        memcpy(&x[regIdx], &m[sp + offset], sizeof(int));
    }
}

/* Assumes that the line has a form of: (lh x11, 3(sp)) or (lh x11, 4(x12)) without trailing spaces */
void lh(const string& reg, const string& from){
    int regIdx = stoi(reg.substr(1, reg.length() - 1));
    int leftBracketIdx = from.find('(');
    int rightBracketIdx = from.find(')');
    string s = from.substr(leftBracketIdx + 1);
    if(s[0] == 'x'){
        s = s.substr(1, s.length() - 2);
        int reg1Val = x[stoi(s)];
        int offset = stoi(from.substr(0, from.length() - (rightBracketIdx - leftBracketIdx + 1)));
        short halfWordValue = *(short*)&m[reg1Val + offset];
        x[regIdx] = halfWordValue;
    } else {
        int offset = stoi(from.substr(0, from.length() - (rightBracketIdx - leftBracketIdx + 1)));
        short halfWordValue = *(short*)&m[sp + offset];
        x[regIdx] = halfWordValue;
    }
}

/* Assumes that the line has a form of: (lb x11, 3(sp)) or (lb x11, 4(x12)) without trailing spaces */
void lb(const string& reg, const string& from){
    int regIdx = stoi(reg.substr(1, reg.length() - 1));
    int leftBracketIdx = from.find('(');
    int rightBracketIdx = from.find(')');
    string s = from.substr(leftBracketIdx + 1);

    if(s[0] == 'x'){
        s = s.substr(1, s.length() - 2);
        int reg1Val = x[stoi(s)];
        int offset = stoi(from.substr(0, from.length() - (rightBracketIdx - leftBracketIdx + 1)));
        int wordValue = *(int*)&m[reg1Val + offset];
        char byteValue = (wordValue >> (8 * (offset % 4))) & 0xFF;
        x[regIdx] = byteValue;
    } else {
        int offset = stoi(from.substr(0, from.length() - (rightBracketIdx - leftBracketIdx + 1)));
        int wordValue = *(int*)&m[sp + offset];
        char byteValue = (wordValue >> (8 * (offset % 4))) & 0xFF;
        x[regIdx] = byteValue;
    }
}

/* Assumes that the line has a form of: (sw x11, 3(sp)) or (sw x11, 4(x12)) without trailing spaces */
void sw(const string& reg, const string& to){
    if(reg == "ra"){ // Handle (sw ra, 4(sp))
        int leftBracketIdx = to.find('(');
        int rightBracketIdx = to.find(')');
        int offset = stoi(to.substr(0, to.length() - (rightBracketIdx - leftBracketIdx + 1)));
        memcpy(&m[sp + offset], &ra, sizeof(int));
        return;
    }

    int regIdx = stoi(reg.substr(1, reg.length() - 1));
    int leftBracketIdx = to.find('(');
    int rightBracketIdx = to.find(')');
    string s = to.substr(leftBracketIdx+1);
    if(s[0] == 'x'){
        s = s.substr(1, s.length()-2);
        int reg1Val = x[stoi(s)];
        int offset =  stoi(to.substr(0, to.length() - (rightBracketIdx - leftBracketIdx + 1)));
        memcpy(&m[reg1Val + offset], &x[regIdx], sizeof(int));
    }else{
        int offset = stoi(to.substr(0, to.length() - (rightBracketIdx - leftBracketIdx + 1)));
        memcpy(&m[sp + offset], &x[regIdx], sizeof(int));
    }
}

/* Assumes that the line has a form of: (sh x11, 3(sp)) or (sh x11, 4(x12)) without trailing spaces */
void sh(const string& reg, const string& to){
    int regIdx = stoi(reg.substr(1, reg.length() - 1));
    int leftBracketIdx = to.find('(');
    int rightBracketIdx = to.find(')');
    string s = to.substr(leftBracketIdx+1);
    if(s[0] == 'x'){
        s = s.substr(1, s.length()-2);
        int reg1Val = x[stoi(s)];
        int offset =  stoi(to.substr(0, to.length() - (rightBracketIdx - leftBracketIdx + 1)));
        memcpy(&m[reg1Val + offset], &x[regIdx], sizeof(short));
    }else{
        int offset = stoi(to.substr(0, to.length() - (rightBracketIdx - leftBracketIdx + 1)));
        memcpy(&m[sp + offset], &x[regIdx], sizeof(short));
    }
}

/* Assumes that the line has a form of: (sb x11, 3(sp)) or (sb x11, 4(x12)) without trailing spaces */
void sb(const string& reg, const string& to){
    int regIdx = stoi(reg.substr(1, reg.length() - 1));
    int leftBracketIdx = to.find('(');
    int rightBracketIdx = to.find(')');
    string s = to.substr(leftBracketIdx+1);
    if(s[0] == 'x'){
        s = s.substr(1, s.length()-2);
        int reg1Val = x[stoi(s)];
        int offset =  stoi(to.substr(0, to.length() - (rightBracketIdx - leftBracketIdx + 1)));
        memcpy(&m[reg1Val + offset], &x[regIdx], sizeof(char));
    }else{
        int offset = stoi(to.substr(0, to.length() - (rightBracketIdx - leftBracketIdx + 1)));
        memcpy(&m[sp + offset], &x[regIdx], sizeof(char));
    }
}

/* Moves 4 bytes from reg2 to reg1 */
void mv(const string& reg1, const string& reg2){
    if(reg2 == "sp"){
        int reg1Idx = stoi(reg1.substr(1, reg1.length() - 1));
        x[reg1Idx] = sp;
        return;
    }

    int reg1Idx = stoi(reg1.substr(1, reg1.length() - 1));
    int reg2Idx = stoi(reg2.substr(1, reg2.length() - 1));
    int val2 = x[reg2Idx];
    x[reg1Idx] = val2;
}

/* If elem1 is greater than or equal to elem2, the command tracker is set to where the branching label is */
void bge(const string& reg1, const string& reg2, const string& label, unordered_map<string, int> &labels, int &currentCommand){
    int reg1Idx = stoi(reg1.substr(1, reg1.length() - 1));
    int reg2Idx = stoi(reg2.substr(1, reg2.length() - 1));
    if(x[reg1Idx] >= x[reg2Idx]){
        int labelIdx = labels[label];
        currentCommand = labelIdx + 1;
    }else{
        currentCommand++;
    }
}

/* If elem1 is lower than or equal to elem2, the command tracker is set to where the branching label is */
void ble(const string& reg1, const string& reg2, const string& label, unordered_map<string, int> &labels, int &currentCommand){
    int reg1Idx = stoi(reg1.substr(1, reg1.length() - 1));
    int reg2Idx = stoi(reg2.substr(1, reg2.length() - 1));
    if(x[reg1Idx] <= x[reg2Idx]){
        int labelIdx = labels[label];
        currentCommand = labelIdx + 1;
    }else{
        currentCommand++;
    }
}

/* If elem1 is equal to elem2, the command tracker is set to where the branching label is */
void beq(const string& reg1, const string& reg2, const string& label, unordered_map<string, int> &labels, int &currentCommand){
    int reg1Idx = stoi(reg1.substr(1, reg1.length() - 1));
    int reg2Idx = stoi(reg2.substr(1, reg2.length() - 1));
    if(x[reg1Idx] == x[reg2Idx]){
        int labelIdx = labels[label];
        currentCommand = labelIdx + 1;
    }else{
        currentCommand++;
    }
}

/* If elem1 is lower than to elem2, the command tracker is set to where the branching label is */
void blt(const string& reg1, const string& reg2, const string& label, unordered_map<string, int> &labels, int &currentCommand){
    int reg1Idx = stoi(reg1.substr(1, reg1.length() - 1));
    int reg2Idx = stoi(reg2.substr(1, reg2.length() - 1));
    if(x[reg1Idx] < x[reg2Idx]){
        int labelIdx = labels[label];
        currentCommand = labelIdx + 1;
    }else{
        currentCommand++;
    }
}

/* If elem1 is greater than to elem2, the command tracker is set to where the branching label is */
void bgt(const string& reg1, const string& reg2, const string& label, unordered_map<string, int> &labels, int &currentCommand){
    int reg1Idx = stoi(reg1.substr(1, reg1.length() - 1));
    int reg2Idx = stoi(reg2.substr(1, reg2.length() - 1));
    if(x[reg1Idx] > x[reg2Idx]){
        int labelIdx = labels[label];
        currentCommand = labelIdx + 1;
    }else{
        currentCommand++;
    }
}

/* If elem1 is not equal to elem2, the command tracker is set to where the branching label is */
void bne(const string& reg1, const string& reg2, const string& label, unordered_map<string, int> &labels, int &currentCommand){
    int reg1Idx = stoi(reg1.substr(1, reg1.length() - 1));
    int reg2Idx = stoi(reg2.substr(1, reg2.length() - 1));
    if(x[reg1Idx] != x[reg2Idx]){
        int labelIdx = labels[label];
        currentCommand = labelIdx + 1;
    }else{
        currentCommand++;
    }
}

/* Immediate addition operation */
void addi(const string& reg1, const string& reg2,  const string& val){
    int value = stoi(val);
    if(reg1 == "sp" && reg2 == "sp"){
        sp += value;
        return;
    }
    int reg1Idx = stoi(reg1.substr(1, reg1.length() - 1));
    int reg2Idx = stoi(reg2.substr(1, reg2.length() - 1));
    int sum = x[reg2Idx] + value;
    memcpy(&x[reg1Idx], &sum, sizeof(int));
}

/* Addition operation */
void add(const string& reg1, const string& reg2,  const string& reg3){
    int reg1Idx = stoi(reg1.substr(1, reg1.length() - 1));
    int reg2Idx = stoi(reg2.substr(1, reg2.length() - 1));
    int reg3Idx = stoi(reg3.substr(1, reg3.length() - 1));
    int sum = x[reg2Idx] + x[reg3Idx];
    memcpy(&x[reg1Idx], &sum, sizeof(int));
}

/* Subtraction operation */
void sub(const string& reg1, const string& reg2,  const string& reg3){
    int reg1Idx = stoi(reg1.substr(1, reg1.length() - 1));
    int reg2Idx = stoi(reg2.substr(1, reg2.length() - 1));
    int reg3Idx = stoi(reg3.substr(1, reg3.length() - 1));
    int sum = x[reg2Idx] - x[reg3Idx];
    memcpy(&x[reg1Idx], &sum, sizeof(int));
}

/* Multiplication operation */
void mul(const string& reg1, const string& reg2,  const string& reg3){
    int reg1Idx = stoi(reg1.substr(1, reg1.length() - 1));
    int reg2Idx = stoi(reg2.substr(1, reg2.length() - 1));
    int reg3Idx = stoi(reg3.substr(1, reg3.length() - 1));
    int sum = x[reg2Idx] * x[reg3Idx];
    memcpy(&x[reg1Idx], &sum, sizeof(int));
}

/* Integer division operation */
void div(const string& reg1, const string& reg2,  const string& reg3){
    int reg1Idx = stoi(reg1.substr(1, reg1.length() - 1));
    int reg2Idx = stoi(reg2.substr(1, reg2.length() - 1));
    int reg3Idx = stoi(reg3.substr(1, reg3.length() - 1));
    int sum = x[reg2Idx] / x[reg3Idx];
    memcpy(&x[reg1Idx], &sum, sizeof(int));
}

/* Prints the contents of the indicated register as an integer, usage: (printInt x11) */
void printInt(const string& reg){
    int regIdx = stoi(reg.substr(1, reg.length() - 1));
    cout<<x[regIdx]<<endl;
}

/* Prints a string on a new line. Usage: (println This will be a printed string) */
void println(const string& line){
    cout<<line<<endl;
}

/*
 * Allocates numBytes bytes on the heap and loads its starting byte's index into the register specified by the user.
 * The allocated memory is not initialized with zeros and user is responsible for managing the memory correctly.
 */
void myMalloc(const string& reg, string numBytess){
    int numBytes = stoi(numBytess);
    int regIdx = stoi(reg.substr(1, reg.length() - 1));
    if(lastAllocationIdx == 0){
        memcpy(&m[0], &numBytes, sizeof(int));
        x[regIdx] = sizeof(int);
    }else {
        int lastAllocSize;
        memcpy(&lastAllocSize, &m[lastAllocationIdx], sizeof(int));
        memcpy(&m[lastAllocationIdx + lastAllocSize + sizeof(int)], &numBytes, sizeof(int));
        lastAllocationIdx += lastAllocSize + sizeof(int);
        x[regIdx] = lastAllocationIdx + sizeof(int);
    }
    allocIndexes.push(lastAllocationIdx);
}

/*
 * Deallocates the memory on heap at the specified address and refreshes lastAllocIdx if Necessary.
 * If unallocated memory is deallocated, user is held responsible for undefined behaviour.
 */
void myFree(const string& address1){
    int address = stoi(address1);
    int deallocNumBytes;
    int zero = 0;
    memcpy(&deallocNumBytes, &m[address - sizeof(int)], sizeof(int));
    memcpy(&m[address - sizeof(int)], &zero, sizeof(int));
    if(address - sizeof(int) == lastAllocationIdx){ //The user has deallocated latest allocated memory
        allocIndexes.pop();
        lastAllocationIdx = allocIndexes.top();
    }
}

/**********************************************************************************************************************/


/* Simulates execution of one asm file based on the processed .txt file */
void launchCode(vector<string> &commands, unordered_map<string, int> &labels){
    int zero = 0;
    memcpy(&m[0], &zero, sizeof(int)); // Helps with the first operation of malloc
    int currentCommand = 1; // Keeps track of which line of the assembler code is running now
    while(true){
        string nextCommand = commands[currentCommand];
        string instruction;
        size_t firstSpacePos = nextCommand.find(' ');
        instruction = nextCommand.substr(0, firstSpacePos);
        auto it = labels.find(instruction.substr(0, instruction.length()-1));
        if(it != labels.end()){ //we have reached a label
            currentCommand++;
            continue;
        }

        if(lowercase(instruction) == "li"){
            size_t commaPos = nextCommand.find(',');
            string registerName = nextCommand.substr(firstSpacePos + 1, commaPos - firstSpacePos - 1);
            string immediateValue = nextCommand.substr(commaPos + 2);
            li(registerName, immediateValue);
            currentCommand++;
        }else if(lowercase(instruction) == "lw"){
            size_t commaPos = nextCommand.find(',');
            string registerName = nextCommand.substr(firstSpacePos + 1, commaPos - firstSpacePos - 1);
            string from = nextCommand.substr(commaPos + 2);
            lw(registerName, from);
            currentCommand++;
        }else if(lowercase(instruction) == "lh"){
            size_t commaPos = nextCommand.find(',');
            string registerName = nextCommand.substr(firstSpacePos + 1, commaPos - firstSpacePos - 1);
            string from = nextCommand.substr(commaPos + 2);
            lh(registerName, from);
            currentCommand++;
        }else if(lowercase(instruction) == "lb"){
            size_t commaPos = nextCommand.find(',');
            string registerName = nextCommand.substr(firstSpacePos + 1, commaPos - firstSpacePos - 1);
            string from = nextCommand.substr(commaPos + 2);
            lb(registerName, from);
            currentCommand++;
        }else if(lowercase(instruction) == "sw"){
            size_t commaPos = nextCommand.find(',');
            string registerName = nextCommand.substr(firstSpacePos + 1, commaPos - firstSpacePos - 1);
            string from = nextCommand.substr(commaPos + 2);
            sw(registerName, from);
            currentCommand++;
        }else if(lowercase(instruction) == "sh"){
            size_t commaPos = nextCommand.find(',');
            string registerName = nextCommand.substr(firstSpacePos + 1, commaPos - firstSpacePos - 1);
            string from = nextCommand.substr(commaPos + 2);
            sh(registerName, from);
            currentCommand++;
        }else if(lowercase(instruction) == "sb"){
            size_t commaPos = nextCommand.find(',');
            string registerName = nextCommand.substr(firstSpacePos + 1, commaPos - firstSpacePos - 1);
            string from = nextCommand.substr(commaPos + 2);
            sb(registerName, from);
            currentCommand++;
        }else if(lowercase(instruction) == "mv"){ // mv x20, x10
            size_t firstCommaPos = nextCommand.find(',');
            size_t secondCommaPos = nextCommand.find(',', firstCommaPos + 1);
            size_t secondSpacePos = nextCommand.find(' ', firstSpacePos + 1);
            string registerName1 = nextCommand.substr(firstSpacePos + 1, firstCommaPos - firstSpacePos - 1);
            string registerName2 = nextCommand.substr(secondSpacePos + 1, secondCommaPos - secondSpacePos - 1);
            mv(registerName1, registerName2);
            currentCommand++;
        }else if(lowercase(instruction) == "blt"){
            size_t firstCommaPos = nextCommand.find(',');
            size_t secondCommaPos = nextCommand.find(',', firstCommaPos + 1);
            size_t secondSpacePos = nextCommand.find(' ', firstSpacePos + 1);
            size_t thirdSpacePos = nextCommand.find(' ', secondSpacePos + 1);
            string registerName1 = nextCommand.substr(firstSpacePos + 1, firstCommaPos - firstSpacePos - 1);
            string registerName2 = nextCommand.substr(secondSpacePos + 1, secondCommaPos - secondSpacePos - 1);
            string label = nextCommand.substr(thirdSpacePos+1);
            blt(registerName1, registerName2, label, labels, currentCommand);
        }else if(lowercase(instruction) == "ble"){
            size_t firstCommaPos = nextCommand.find(',');
            size_t secondCommaPos = nextCommand.find(',', firstCommaPos + 1);
            size_t secondSpacePos = nextCommand.find(' ', firstSpacePos + 1);
            size_t thirdSpacePos = nextCommand.find(' ', secondSpacePos + 1);
            string registerName1 = nextCommand.substr(firstSpacePos + 1, firstCommaPos - firstSpacePos - 1);
            string registerName2 = nextCommand.substr(secondSpacePos + 1, secondCommaPos - secondSpacePos - 1);
            string label = nextCommand.substr(thirdSpacePos+1);
            ble(registerName1, registerName2, label, labels, currentCommand);
        }else if(lowercase(instruction) == "beq"){
            size_t firstCommaPos = nextCommand.find(',');
            size_t secondCommaPos = nextCommand.find(',', firstCommaPos + 1);
            size_t secondSpacePos = nextCommand.find(' ', firstSpacePos + 1);
            size_t thirdSpacePos = nextCommand.find(' ', secondSpacePos + 1);
            string registerName1 = nextCommand.substr(firstSpacePos + 1, firstCommaPos - firstSpacePos - 1);
            string registerName2 = nextCommand.substr(secondSpacePos + 1, secondCommaPos - secondSpacePos - 1);
            string label = nextCommand.substr(thirdSpacePos+1);
            beq(registerName1, registerName2, label, labels, currentCommand);
        }else if(lowercase(instruction) == "bne"){
            size_t firstCommaPos = nextCommand.find(',');
            size_t secondCommaPos = nextCommand.find(',', firstCommaPos + 1);
            size_t secondSpacePos = nextCommand.find(' ', firstSpacePos + 1);
            size_t thirdSpacePos = nextCommand.find(' ', secondSpacePos + 1);
            string registerName1 = nextCommand.substr(firstSpacePos + 1, firstCommaPos - firstSpacePos - 1);
            string registerName2 = nextCommand.substr(secondSpacePos + 1, secondCommaPos - secondSpacePos - 1);
            string label = nextCommand.substr(thirdSpacePos+1);
            bne(registerName1, registerName2, label, labels, currentCommand);
        }else if(lowercase(instruction) == "bgt"){
            size_t firstCommaPos = nextCommand.find(',');
            size_t secondCommaPos = nextCommand.find(',', firstCommaPos + 1);
            size_t secondSpacePos = nextCommand.find(' ', firstSpacePos + 1);
            size_t thirdSpacePos = nextCommand.find(' ', secondSpacePos + 1);
            string registerName1 = nextCommand.substr(firstSpacePos + 1, firstCommaPos - firstSpacePos - 1);
            string registerName2 = nextCommand.substr(secondSpacePos + 1, secondCommaPos - secondSpacePos - 1);
            string label = nextCommand.substr(thirdSpacePos+1);
            bgt(registerName1, registerName2, label, labels, currentCommand);
        }else if(lowercase(instruction) == "bge"){
            size_t firstCommaPos = nextCommand.find(',');
            size_t secondCommaPos = nextCommand.find(',', firstCommaPos + 1);
            size_t secondSpacePos = nextCommand.find(' ', firstSpacePos + 1);
            size_t thirdSpacePos = nextCommand.find(' ', secondSpacePos + 1);
            string registerName1 = nextCommand.substr(firstSpacePos + 1, firstCommaPos - firstSpacePos - 1);
            string registerName2 = nextCommand.substr(secondSpacePos + 1, secondCommaPos - secondSpacePos - 1);
            string label = nextCommand.substr(thirdSpacePos+1);
            bge(registerName1, registerName2, label, labels, currentCommand);
        }else if(lowercase(instruction) == "jump"){
            string label = nextCommand.substr(firstSpacePos + 1);
            currentCommand = labels[label] + 1;
        }else if(lowercase(instruction) == "call"){
            string label = nextCommand.substr(firstSpacePos + 1);
            ra = currentCommand + 1;
            currentCommand = labels[label] + 1;
        }else if(lowercase(instruction) == "addi"){
            size_t firstCommaPos = nextCommand.find(',');
            size_t secondCommaPos = nextCommand.find(',', firstCommaPos + 1);
            size_t secondSpacePos = nextCommand.find(' ', firstSpacePos + 1);
            size_t thirdSpacePos = nextCommand.find(' ', secondSpacePos + 1);
            string registerName1 = nextCommand.substr(firstSpacePos + 1, firstCommaPos - firstSpacePos - 1);
            string registerName2 = nextCommand.substr(secondSpacePos + 1, secondCommaPos - secondSpacePos - 1);
            string val = nextCommand.substr(thirdSpacePos+1);
            addi(registerName1, registerName2, val);
            currentCommand++;
        }else if(lowercase(instruction) == "add"){
            size_t firstCommaPos = nextCommand.find(',');
            size_t secondCommaPos = nextCommand.find(',', firstCommaPos + 1);
            size_t secondSpacePos = nextCommand.find(' ', firstSpacePos + 1);
            size_t thirdSpacePos = nextCommand.find(' ', secondSpacePos + 1);
            string registerName1 = nextCommand.substr(firstSpacePos + 1, firstCommaPos - firstSpacePos - 1);
            string registerName2 = nextCommand.substr(secondSpacePos + 1, secondCommaPos - secondSpacePos - 1);
            string registerName3 = nextCommand.substr(thirdSpacePos+1);
            add(registerName1, registerName2, registerName3);
            currentCommand++;
        }else if(lowercase(instruction) == "sub"){
            size_t firstCommaPos = nextCommand.find(',');
            size_t secondCommaPos = nextCommand.find(',', firstCommaPos + 1);
            size_t secondSpacePos = nextCommand.find(' ', firstSpacePos + 1);
            size_t thirdSpacePos = nextCommand.find(' ', secondSpacePos + 1);
            string registerName1 = nextCommand.substr(firstSpacePos + 1, firstCommaPos - firstSpacePos - 1);
            string registerName2 = nextCommand.substr(secondSpacePos + 1, secondCommaPos - secondSpacePos - 1);
            string registerName3 = nextCommand.substr(thirdSpacePos+1);
            sub(registerName1, registerName2, registerName3);
            currentCommand++;
        }else if(lowercase(instruction) == "mul"){
            size_t firstCommaPos = nextCommand.find(',');
            size_t secondCommaPos = nextCommand.find(',', firstCommaPos + 1);
            size_t secondSpacePos = nextCommand.find(' ', firstSpacePos + 1);
            size_t thirdSpacePos = nextCommand.find(' ', secondSpacePos + 1);
            string registerName1 = nextCommand.substr(firstSpacePos + 1, firstCommaPos - firstSpacePos - 1);
            string registerName2 = nextCommand.substr(secondSpacePos + 1, secondCommaPos - secondSpacePos - 1);
            string registerName3 = nextCommand.substr(thirdSpacePos+1);
            mul(registerName1, registerName2, registerName3);
            currentCommand++;
        }else if(lowercase(instruction) == "div"){
            size_t firstCommaPos = nextCommand.find(',');
            size_t secondCommaPos = nextCommand.find(',', firstCommaPos + 1);
            size_t secondSpacePos = nextCommand.find(' ', firstSpacePos + 1);
            size_t thirdSpacePos = nextCommand.find(' ', secondSpacePos + 1);
            string registerName1 = nextCommand.substr(firstSpacePos + 1, firstCommaPos - firstSpacePos - 1);
            string registerName2 = nextCommand.substr(secondSpacePos + 1, secondCommaPos - secondSpacePos - 1);
            string registerName3 = nextCommand.substr(thirdSpacePos+1);
            div(registerName1, registerName2, registerName3);
            currentCommand++;
        }else if(lowercase(instruction) == "mymalloc"){
            size_t commaPos = nextCommand.find(',');
            string registerName = nextCommand.substr(firstSpacePos + 1, commaPos - firstSpacePos - 1);
            string immediateValue = nextCommand.substr(commaPos + 2);
            myMalloc(registerName, immediateValue);
            currentCommand++;
        }else if(lowercase(instruction) == "myfree"){  //myFree 213
            string idx = nextCommand.substr(firstSpacePos+1);
            myFree(idx);
            currentCommand++;
        }else if(lowercase(instruction) == "printint"){
            string reg = nextCommand.substr(firstSpacePos + 1);
            printInt(reg);
            currentCommand++;
        }else if(lowercase(instruction) == "println"){
            string line = nextCommand.substr(firstSpacePos+1);
            println(line);
            currentCommand++;
        }else if(lowercase(instruction) == "ret"){
            currentCommand = ra;
        }else if(lowercase(instruction) == "exit"){
            currentCommand++;
            break;
        }else{
            break;
        }
    }
}

/* Processes a single assembly command and executes it */
bool processCommand(const string& command, int &lineNumber, unordered_map<string, int> &labels){
    if(size(command) == 0 || command[0] == '#')return true; // If there is an empty line, go to the next line

    string instruction;
    size_t firstSpacePos = command.find(' ');
    if(command == "exit"){
        return true;
    }
    instruction = command.substr(0, firstSpacePos);
    if(lowercase(instruction) == "call"){
        if(!checkedRA){          //for initializing the first return address correctly
            ra = lineNumber+1;
            checkedRA = true;
        }
    }
    if(validCommands.count(lowercase(instruction))){
        return true;
    }else if(instruction[size(instruction)-1] == ':'  ){ // if it ends on ':', it is a function label
        labels[instruction.substr(0, size(instruction) - 1)] = lineNumber;
        return true;
    }else{
        cout<<"ERROR on line: " << lineNumber << endl;
        cout<<"Invalid instruction: " << instruction <<endl;
        return false;
    }
}

/*
 * Initialises CPU registers with 0 values and valid assembly commands.
 * RAM values are not initially set to 0,
 * as it is the client's responsibility to manage
 * memory correctly.
 */
void initAssembler(){
    for(int i = 0; i < 100; i++){
        x[i] = 0;
    }
    validCommands.insert({"li", "lw", "lh", "lb",
                            "sw", "sh", "sb", "mv",
                            "blt", "ble", "beq", "bne", "bgt", "bge",
                            "ret", "exit", "jump", "call",
                            "addi", "add", "sub", "mul", "div",
                            "printint", "println",
                            "mymalloc", "myfree"});
}

/*
 * Tries to open the inputted file and if successful, starts processing.
 * Otherwise, the client is asked for another input.
 */
void processFile(const string& path) {
    fstream newfile;
    newfile.open(path.c_str(), ios::in);
    if (newfile.is_open()) {
        vector<string> commands;
        unordered_map<string, int> labels;
        commands.push_back("dummyString"); //So that indexation of lines starts from 1
        string command;
        initAssembler();
        int lineNumber = 1;
        while (getline(newfile, command)) {
            if(processCommand(command, lineNumber, labels)){
                if(command.length() != 0 && command[0] != '#') {
                    commands.push_back(command);
                    lineNumber++;
                }
            }else{
                break;
            }
        }
        newfile.close();
        // command initialization and label indexation is done
        launchCode(commands, labels);
    } else {
        cout << "Error opening the file, try again.\n";
    }
}

/* Launches a loop of assembly .txt input requests until termination string has been inputted. */
void launchProgram(){
    while(true){
        string path;
        cout<<"Provide the full path to the assembly .txt file (Or type END to terminate the program): ";
        cin>>path;
        if(path == "END")break;
        processFile(path);
        sp = RAM_SIZE;
        ra = 1;
        lastAllocationIdx = 0;
        checkedRA = false;
        memcpy(&m[0], &lastAllocationIdx, sizeof(int));
        while (!allocIndexes.empty()) {
            allocIndexes.pop();
        }
    }
}

int main() {
    launchProgram();
    return 0;
}