# 16-bit Processor 


The 16-bit processor supports 19 operations:
    ALU operations:
    add, sub, mul, div, shiftl, shiftr, not, and, or, nand, xor, nor.
    Memory access operations:
    load, store, li (loads a constant value directly into ram).
    Branching operations:
    jmp, brne, breq.


The 16-bit processor consists of 2 main parts: **CPU and peripheral blocks.**
1) **CPU** The 16-bit CPU has 4 parts:
    1. **Instruction decoding and ALU operation handling**: ROM in the "instructions" subcircuit functions as the instruction set. This part of the processor reads a 64 bit instruction and decides whether it is an ALU, branching or load/store operation. It performs the ALU operation or redirects the non-ALU operation to other blocks. 
    2. **Branch operation and ProgramCounter handling**: This block makes sure that program counter is increasing with the clock and monitors branching operations. Program counter is simply the address of an instruction in the ROM.
    3. **CPU Registers**: These are the inbuilt registers of the processor. The user has 8 CPU registers at their disposal.
    4. **RAM Registers**: These are the registers representing RAM of the processor. The user has 8 RAM addresses at their disposal.

2) **Peripheral** This block generates a PWM signal on the GPIOout pin if the correct code is written into ROM. It also monitors any  interrupt actions and transfers this information to the program counter program, signalling it to jump to a desired instruction set address.


**Structure of a single 64-bit instruction (from the Most Significant Bit)**

[First 16 bit block] - Operation type
[Second 16 bit block] - First operand (if exists)
[Third 16 bit block] - Second operand (if exists)
[Fourth 16 bit block] - Third operand (if exists)
If an operand does not exist, it is simply padded with zeros.



**Test codes** (these are translated to machine code in the txt file via the cpp file provided, put them into the ROM of "instructions" subcircuit): 

*addition.txt*
ALU operation test (Testing addition operation): In the end, the x0 register should display 26
li m0 12
li m1 14
store x0 m1
store x1 m0
add x0 x0 x1
exit

*forLoop.txt*
Branching operation test (Testing for loop): x0 register should iterate from 0 to 125
li m0 125
store x2 m0
li m0 0
store x0 m0
li m0 1
store x1 m0
add x0 x0 x1
brne 6 x0 x2
exit

*PWM.txt*
PWM generation: PWM signal will be generated in the x0 CPU register and outputted on the GPIOoutput pin
li m0 0
li m1 1
store x0 m1
store x0 m0
store x0 m0
store x0 m1
jmp 3
exit

*interruptForLoop.txt*
Interrupt testing: 127 for loop should be interrupted via the following action - RAM registers m0,m1,m2 and m3 will be filled with numbers 1,2,3,4 and program will end. Some specific pins need to be set for a successful test. All details are in the circ file.
li m0 127
store x2 m0
li m0 0
store x0 m0
li m0 1
store x1 m0
add x0 x0 x1
brne 6 x0 x2
exit
......
(This interrupting action is somewhere else in ROM)
li x0 1
li x1 2
li x2 3
li x3 4
exit