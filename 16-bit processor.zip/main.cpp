#include <iostream>
#include <string>
#include <sstream>
#include <map>
#include <iomanip>
#include <vector>
using namespace std;

string getBytecode(const string& text) {
    static map<string, uint16_t> instructionMap = {
            {"add", 0}, {"sub", 1}, {"mul", 2}, {"div", 3},
            {"shiftl", 4}, {"shiftr", 5}, {"not", 6}, {"and", 7},
            {"or", 8}, {"nand", 9}, {"xor", 10}, {"nor", 11},
            {"load", 12}, {"store", 13}, {"jmp", 14}, {"brne", 15},
            {"breq", 16}, {"li", 17}, {"exit", 18}
    };

    istringstream iss(text);
    string instruction;
    iss >> instruction;

    uint64_t bytecode = 0;

    bytecode |= (uint64_t)instructionMap[instruction] << 48;

    for (int i = 0; i < 3; i++) {
        string param;
        if (iss >> param) {
            if (param[0] == 'x') {
                // Register: xN -> N
                uint16_t regNum = stoi(param.substr(1));
                bytecode |= (uint64_t)regNum << (32 - i * 16);
            } else if (param[0] == 'm') {
                // RAM address: mN -> N
                uint16_t memAddr = stoi(param.substr(1));
                bytecode |= (uint64_t)memAddr << (32 - i * 16);
            } else {
                // Immediate value
                bytecode |= (uint64_t)stoi(param) << (32 - i * 16);
            }
        }
    }

    // Convert to hexadecimal
    stringstream ss;
    ss << setfill('0') << setw(16) << hex << bytecode;
    return ss.str();
}

int main() {
    string line;
    vector<string> bytecodes;

    while (getline(cin, line) && !line.empty()) {
        bytecodes.push_back(getBytecode(line));
    }

    // Option 1: Output each instruction on a new line
    for (const auto& bytecode : bytecodes) {
        cout << bytecode << endl;
    }

    // Option 2: Output as a continuous string
    /*
    string continuousOutput = "";
    for (const auto& bytecode : bytecodes) {
        continuousOutput += bytecode;
    }
    cout << continuousOutput << endl;
    */

    return 0;
}